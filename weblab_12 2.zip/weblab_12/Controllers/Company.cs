﻿using Microsoft.AspNetCore.Mvc;
using Mvcweblab.Data;
using System.Linq;

namespace weblab.Controllers
{
    public class CompanyController : Controller
    {
        private readonly EmployeeContext _context;

        public CompanyController(EmployeeContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var companyDetailsList = (
                from company in _context.Companies
                join employee in _context.Employees on company.Id equals employee.CompanyId into gj
                from subEmployee in gj.DefaultIfEmpty()
                group subEmployee by new { company.Id, company.Name, company.Address, company.City, company.Country } into grp
                select new CompanyDetailsDto
                {
                    Id = grp.Key.Id,
                    Name = grp.Key.Name,
                    FullAddress = $"{grp.Key.Address}, {grp.Key.City}, {grp.Key.Country}",
                    NumberOfEmployees = grp.Count(e => e != null)
                }).ToList();

            return View(companyDetailsList);
        }
    }
}
