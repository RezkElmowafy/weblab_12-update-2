﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Mvcweblab.Models
{
    public class Company
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 100 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Zipcode is required")]
        [StringLength(5, MinimumLength = 5, ErrorMessage = "Zipcode must be exactly 5 digits")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Zipcode can only contain digits")]
        public string Zipcode { get; set; }

        [StringLength(50, ErrorMessage = "City cannot be longer than 50 characters")]
        public string City { get; set; }

        [StringLength(60, ErrorMessage = "Country cannot be longer than 60 characters")]
        public string Country { get; set; }

        public ICollection<Employee> Employees { get; set; } = new List<Employee>();
    }
}
